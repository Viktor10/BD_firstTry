#Clear
Truncate all tables.

## Supported request methods 
* POST

##Supported formats
* json

##Arguments

Requesting http://some.host.ru/db/api/clear/ with **{}**:
```json
{"code": 0, "response": "OK"}
```
