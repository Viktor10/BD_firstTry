#%(header)s
%(description)s

## Supported request methods 
* %(method)s
%(formats)s
##Arguments
%(optional)s

%(requried)s

Requesting %(url)s%(params)s:
```json
%(response)s
```
